<?php

namespace Aimeos\Controller\Frontend\Subscription;


class Invalid
{
}
