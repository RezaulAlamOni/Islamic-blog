<?php

namespace Aimeos\Controller\Frontend\Customer;


class Invalid
{
}
