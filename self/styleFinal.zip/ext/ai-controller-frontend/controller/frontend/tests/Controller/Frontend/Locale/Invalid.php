<?php

namespace Aimeos\Controller\Frontend\Locale;


class Invalid
{
}
