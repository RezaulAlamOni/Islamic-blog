<?php

namespace Aimeos\Controller\Frontend\Supplier;


class Invalid
{
}
